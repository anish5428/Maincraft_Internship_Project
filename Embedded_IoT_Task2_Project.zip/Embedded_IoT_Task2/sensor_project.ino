int sensor=A0; int led=13;
void setup(){pinMode(led,OUTPUT);Serial.begin(9600);}
void loop(){int v=analogRead(sensor);Serial.println(v);if(v<300)digitalWrite(led,HIGH);else digitalWrite(led,LOW);delay(500);}