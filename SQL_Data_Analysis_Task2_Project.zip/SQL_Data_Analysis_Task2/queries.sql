SELECT c.name,AVG(e.grade) FROM courses c JOIN enrollments e ON c.id=e.course_id GROUP BY c.name;
SELECT * FROM enrollments ORDER BY grade DESC LIMIT 3;