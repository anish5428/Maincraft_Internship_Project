SELECT * FROM sales;
SELECT region,SUM(sales) FROM sales GROUP BY region;