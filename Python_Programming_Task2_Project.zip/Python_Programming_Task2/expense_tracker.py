import csv
def add_expense(item,amount):
    with open('expenses.csv','a',newline='') as f:
        csv.writer(f).writerow([item,amount])
print('Expense Tracker')
