from flask import Flask,render_template,request,redirect,session
app=Flask(__name__)
app.secret_key='secret'
users={}
@app.route('/',methods=['GET','POST'])
def login():
    return 'Login Page'
@app.route('/register')
def register():
    return 'Register Page'
app.run()
