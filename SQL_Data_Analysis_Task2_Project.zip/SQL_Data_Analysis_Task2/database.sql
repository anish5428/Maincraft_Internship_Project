CREATE TABLE courses(id INT,name VARCHAR(50));
CREATE TABLE enrollments(student_id INT,course_id INT,grade INT);
SELECT * FROM enrollments;