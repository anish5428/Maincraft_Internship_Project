print('DroneKit Waypoint Mission Starter')
# connect, arm, takeoff, goto waypoints, RTL
