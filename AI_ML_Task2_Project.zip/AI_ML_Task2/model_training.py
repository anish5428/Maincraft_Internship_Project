from sklearn.datasets import fetch_california_housing
print('Train Linear Regression, Ridge, Decision Tree')